  <!DOCTYPE html>
  <?php 
  session_start();
  if (!isset($_SESSION['nom']))
  {
    header('location:login.php');
  }
  
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "maraude";
  try
  {
    $bdd = new PDO('mysql:host=localhost;dbname=maraude;charset=utf8', 'root', '');
  }
  catch (Exception $e)
  {
    die('Erreur : ' . $e->getMessage());
  }
  ?>

  <html>
  <head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href=" style.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <script>
      $( function() {
        $( "#datepicker" ).datepicker();
      } );
    </script>
  </head>
  <body>
    <h1><?php echo $_SESSION['nom']; ?></h1>
    <nav class="navbar navbar-light bg-light fixed fixed-top">
      <h4 style="margin-left: 550px; color: blue;">PROJET MARAUDE</h4>
    </nav>
    <div class="container">
      <br>
      <br>
      <br>
      <h5 style="text-decoration: underline;font-style: italic;">Insertion beneficiaire</h5>
      <br>
      <form action="select.php" method="POST">
        Nom: <input type="text" name="nom" > 
        Prenom: <input type="text" name="prenom"> 
        Surnom: <input type="text" name="surnom"> 
        Date de naissance:<input type="text" name="date_de_naissance" id="datepicker"> 
        <input type="submit" name="submit" class="btn btn-primary btn-md">
      </form>
      <br>
      <br> 
      <div style="background-color: lightgrey">
        <table class="table table-bordered">
          <thead>
            <tr>
             <th>Id</th>
             <th>Nom</th>
             <th>Prenom</th>
             <th>Surnom</th>
             <th>Date de naissance</th>
           </tr>
           <?php
           $reponse = $bdd->query('SELECT * FROM beneficiaire');
           while ($donnees = $reponse->fetch())
           {
            ?>
            <tr>
              <td><?php   echo $donnees['id_beneficiaire'];?>  </td>
              <td><?php   echo $donnees['nom'];?>  </td>
              <td><?php   echo $donnees['prenom'];?>  </td>
              <td><?php   echo $donnees['surnom'];?>  </td> 
              <td><?php   echo $donnees['date_de_naissance'];?>  </td> 
              <td><a href="select.php?id_beneficiaire=<?php  echo $donnees['id_beneficiaire']; ?>">suprimer</a></td>
              <td><a href="update.php?idr=<?php  echo $donnees['id_beneficiaire'];?>">modifier</a></td>        
            </tr>
            <?php }
            ?> 

          </tbody>
        </table>   
      </div>
      <br>
    </div>
    <div class="container">
     <h5 style="text-decoration: underline;font-style: italic;">Insertion localisation</h5>
     <br>
     <form action="select.php" method="POST" style="margin-left: 450px;">
      Nom du localisation: <input type="text" name="nom_localisation">
      capitale: <input type="text" name="capitale">
      <input type="submit" name="io" class="btn btn-primary btn-md">
    </form>
    <br>
    <br>
    <div style="background-color: lightgrey">
     <table class="table table-bordered">
       <tr>
        <th>Id_localisation</th>
        <th>Nom_localisation</th>
        <th>capitale</th>
      </tr>
      <?php
      $reponse = $bdd->query('SELECT * FROM localisation');
      while ($donnees = $reponse->fetch())
      {
        ?>
        <tr>
          <td><?php   echo $donnees['id_localisation'];?>  </td>
          <td><?php   echo $donnees['nom_localisation'];?>  </td>
          <td><?php   echo $donnees['capitale'];?>  </td>
          <td><a href="select.php?id_localisation=<?php  echo $donnees['id_localisation']; ?>">suprimer</a></td>
          <td><a href="update.php?idr=<?php  echo $donnees['id_localisation']; ?>">modifier</a></td>
        </tr>
        <?php } ?>   
      </table>
    </div>
  </div>

</body>
</html>
