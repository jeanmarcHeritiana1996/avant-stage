<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maraude";
try
{
	$conn = new PDO('mysql:host=localhost;dbname=maraude;charset=utf8', 'root', '');
}
catch (Exception $e)
{
	die('Erreur : ' . $e->getMessage());
}

if (isset($_POST['envoyer'])) {
	$insertpers = "INSERT INTO admin (nom,mot_de_passe,entite) VALUES ('%s','%s','%s')";
	$insertpers = sprintf($insertpers,$_POST['nom'],$_POST['mot_de_passe'],$_POST['entite']);
	$insertp = $conn->prepare($insertpers); 
	if ($insertp->execute()) {
		header('location:login.php');
	}
	else
	{
		echo 'non';
	}
}
?>
