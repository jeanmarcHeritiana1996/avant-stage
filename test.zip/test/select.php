<?php 
session_start();
if (isset($_SESSION['nom'])) {
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
	</head>
	<body>
		<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "maraude";
		try
		{
			$conn = new PDO('mysql:host=localhost;dbname=maraude;charset=utf8', 'root', '');

		}
		catch (Exception $e)
		{
			die('Erreur : ' . $e->getMessage());
		}
		if (isset($_POST['submit'])) {
			$sql = "INSERT INTO beneficiaire (nom, prenom,surnom,date_de_naissance)
			VALUES ('%s','%s','%s', STR_TO_DATE('%s','%%m/%%d/%%Y'))";
			$sql = sprintf($sql,$_POST['nom'],$_POST['prenom'],$_POST['surnom'],$_POST["date_de_naissance"]);
			$insert = $conn->prepare($sql);
			if ($insert->execute()){
				header('location:index.php');
			}
			else
			{
				echo 'non';
			}

		}

		if (isset($_GET['id_beneficiaire'])){

			$delet = "DELETE from beneficiaire where id_beneficiaire = %s";
			$delet = sprintf($delet,$_GET['id_beneficiaire']);
			$del = $conn->prepare($delet);
			if ($del->execute()) {
				header('location:index.php');
			}
			else	
			{
				echo 'non';
			}

		}

		if(isset($_POST['updat'])){

			$updat = "UPDATE beneficiaire set nom = '%s',prenom = '%s',surnom = '%s',date_de_naissance =STR_TO_DATE('%s','%%m/%%d/%%Y') where id_beneficiaire= %s";

			$updat = sprintf($updat,$_POST['nom'],$_POST['prenom'],$_POST['surnom'],$_POST['date_de_naissance'],$_POST['id_beneficiaire']);
			$upt = $conn->prepare($updat);
			if ( $upt->execute()) {
				header('location:index.php');
			}
			else{
				echo 'hahahahahaha';
			}
		}
      //efa localisation tsika izao
		if (isset($_POST['io'])){

			$insertloc = "INSERT INTO localisation (nom_localisation, capitale)
			VALUES ('%s','%s')";
			$insertloc = sprintf($insertloc,$_POST['nom_localisation'],$_POST['capitale'],$_POST['id_localisation']);
			$inloc = $conn->prepare($insertloc);
			if ($inloc->execute()){
				header('location:index.php');
			}
			else
			{
				echo 'non';
			}

		}

		if (isset($_GET['id_localisation'])) {

			$deleteloc = "DELETE from localisation where id_localisation = '%s'";
			$deleteloc = sprintf($deleteloc,$_GET['id_localisation']);
			$delloc = $conn->prepare($deleteloc);
			if ($delloc->execute()) {
				header('location:index.php');
			}
			else
			{
				echo 'non';
			}
		}

		if (isset($_POST['updatlocat'])) {

			$updatloc = "UPDATE localisation set nom_localisation = '%s',capitale = '%s' where id_localisation = %s";
			$updatloc = sprintf($updatloc,$_POST['nom_localisation'],$_POST['capitale'],$_POST['id_localisation']);
			$uptloc = $conn->prepare($updatloc);
			if ( $uptloc->execute()) {
				header('location:index.php');
			}
			else
			{
				echo 'hahahahahaha';
			}
		} 
		if (isset($_POST['connection'])) {
			$log = "SELECT from admin WHERE nom = '%s' AND mot_de_passe = '%s' AND entite = '%s'";
			$log = sprintf($log,$_POST['nom'],$_POST['mot_de_passe'],$_POST['entite']);
			$logn = $conn->prepare($log);
			if($logn->execute()) {
				session_start();
				$_SESSION['nom'];
				echo 'ok';

			}
			else
			{
				echo 'non';
			}
		}

		?>
	</body>
	</html>
	<?php } ?>
	?>
