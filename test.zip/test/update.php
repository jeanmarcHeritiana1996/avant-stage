<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maraude";
try
{
	$conn = new PDO('mysql:host=localhost;dbname=maraude;charset=utf8', 'root', '');
}
catch (Exception $e)
{
	die('Erreur : ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href=" style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">	
</head>
<body>
	<div class="container">
		<h2>MODIFICATION du beneficiaire</h2>
		<br>
		<?php
		$updat = "SELECT * FROM beneficiaire   where id_beneficiaire = %s ";
		$updat = sprintf($updat,$_GET['idr']);
		$upt = $conn->query($updat);
		while ($donne=$upt->fetch()) { ?> 
		<div style="background-color: lightgrey">
			<form action="select.php" method="POST">
				<input type="hidden" name="id_beneficiaire" value="<?php echo $donne['id_beneficiaire']; ?>">
				Nom: <input type="text" name="nom" value="<?php echo $donne['nom']; ?>"> 
				Prenom: <input type="text" name="prenom" value="<?php echo $donne['prenom']; ?>"> 
				Surnom: <input type="text" name="surnom" value="<?php echo $donne['surnom']; ?>"> 
				Date de naissance:<input type="text" name="date_de_naissance" id="datepicker" value="<?php echo $donne['date_de_naissance']; ?>"> 
				<input type="submit" name="updat">
			</form>
			<?php   }  
			?>         
		</div>
		<br>

		<div  class="container">
			<h2>MODIFICATION du localisation</h2>
			<br>
			<?php
			$insertloc = "SELECT * FROM localisation   where id_localisation = %s ";
			$insertloc = sprintf($insertloc,$_GET['idr']);
			$inloc = $conn->query($insertloc);
			while ($donne=$inloc->fetch()) { 
				?> 
				<div style="background-color: lightgrey">
					<form action="select.php" method="POST">
						<input type="hidden" name="id_localisation" value="<?php echo $donne['id_localisation']; ?>">
						nom_localisation: <input type="text" name="nom_localisation" value="<?php echo $donne['nom_localisation']; ?>"> 
						capitale: <input type="text" name="capitale" value="<?php echo $donne['capitale']; ?>"> 
						<input type="submit" name="updatlocat">
					</form>
					<?php } 
					?>         
				</div>
				<br>
			</div>	
		</body>
		</html>